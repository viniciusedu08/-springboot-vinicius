package Vinicius.Projeto01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto01Application {

	public static void main(String[] args) {
		SpringApplication.run(Projeto01Application.class, args);
	}

}
